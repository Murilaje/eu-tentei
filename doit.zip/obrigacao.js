document.addEventListener("DOMContentLoaded", () => {
    const items = document.querySelectorAll(".itemany");

    items.forEach(item => {
        const checkbox = item.querySelector(".checkboxdone");
        const label = item.querySelector("label");
        const janelaany = item.querySelector(".janelaany");
        const parabensGif = item.querySelector(".parabens-gif");

        janelaany.style.display = "none";

        label.addEventListener("click", (event) => {
            event.stopPropagation();
            janelaany.style.display = janelaany.style.display === "none" ? "block" : "none";
        });

        document.addEventListener("click", (event) => {
            if (!item.contains(event.target)) {
                janelaany.style.display = "none";
            }
        });

        checkbox.addEventListener("change", () => {
            if (checkbox.checked) {
                parabensGif.style.display = "block";
            } else {
                parabensGif.style.display = "none";
            }
        });
    });
});
